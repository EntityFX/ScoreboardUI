﻿using EntityFX.ScoreboardUI.Elements.Controls;
using EntityFX.ScoreboardUI.Elements.Scoreboards;

namespace EntityFx.ScorbordUI.TestExample
{
    class ThirdScoreboard : Scoreboard
    {
        public ThirdScoreboard()
            : base(new Panel())
        {
        }
    }
}