﻿using EntityFX.ScoreboardUI.Elements.Controls;
using EntityFX.ScoreboardUI.Elements.Scoreboards;

namespace EntityFx.ScorbordUI.TestExample
{
    class FourthScoreboard : Scoreboard
    {
        public FourthScoreboard()
            : base(new Panel())
        {
        }
    }
}