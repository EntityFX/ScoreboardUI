﻿namespace EntityFX.ScoreboardUI
{
    public delegate void KeyPressEventHandler(
        UiElement sender,
        KeyPressEventArgs e
        );
}