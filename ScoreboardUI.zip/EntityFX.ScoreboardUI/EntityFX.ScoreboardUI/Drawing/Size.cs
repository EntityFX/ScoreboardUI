﻿namespace EntityFX.ScoreboardUI.Drawing
{
    public struct Size
    {
        public int Height { get; set; }

        public int Width { get; set; }
    }
}