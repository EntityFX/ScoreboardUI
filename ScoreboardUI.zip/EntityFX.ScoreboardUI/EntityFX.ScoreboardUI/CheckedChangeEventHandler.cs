﻿using EntityFX.ScoreboardUI.Elements.Controls;

namespace EntityFX.ScoreboardUI
{
    public delegate void CheckedChangeEventHandler(
        ToggleButtonBase sender
        );
}