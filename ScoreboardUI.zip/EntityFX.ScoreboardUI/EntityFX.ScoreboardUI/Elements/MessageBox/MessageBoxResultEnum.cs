﻿namespace EntityFX.ScoreboardUI.Elements.MessageBox
{
    public enum MessageBoxResultEnum
    {
        Ok,
        Yes,
        No,
        Cancel,
        None
    }
}