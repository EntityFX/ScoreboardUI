﻿namespace EntityFX.ScoreboardUI.Elements.MessageBox
{
    public enum MessageBoxTypeEnum
    {
        Error,
        Warning,
        Info,
        Question,
        None
    }
}