﻿namespace EntityFX.ScoreboardUI.Elements.MessageBox
{
    public enum MessageBoxButtonsEnum
    {
        Ok,
        OkCancel,
        YesNo,
        YesNoCancel
    }
}