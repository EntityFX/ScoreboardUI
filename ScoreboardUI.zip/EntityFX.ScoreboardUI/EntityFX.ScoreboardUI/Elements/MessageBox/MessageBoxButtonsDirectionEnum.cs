﻿namespace EntityFX.ScoreboardUI.Elements.MessageBox
{
    public enum MessageBoxButtonsDirectionEnum
    {
        Vertical,
        Horizontal
    }
}