﻿namespace EntityFX.ScoreboardUI.Elements.Scoreboards
{
    public enum TitleAligment
    {
        Left,
        Center,
        Right
    }
}