﻿using System.Collections.Generic;

namespace EntityFX.ScoreboardUI.Elements.Controls.Table
{
    public class TableHeaderRow : TableRow<TableHeaderCell, Label>
    {
    }
}