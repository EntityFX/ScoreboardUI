﻿namespace EntityFX.ScoreboardUI.Elements.Controls.Table
{
    public class TableButtonCellBaseBase : TableCellBase
    {
         
    }
}