﻿namespace EntityFX.ScoreboardUI.Elements.Controls.Table
{
    public class TableViewRow : TableRow<TableCellBase, ControlBase>
    {
    }
}