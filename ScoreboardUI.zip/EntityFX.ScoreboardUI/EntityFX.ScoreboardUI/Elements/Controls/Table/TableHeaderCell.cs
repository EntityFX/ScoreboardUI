﻿namespace EntityFX.ScoreboardUI.Elements.Controls.Table
{
    public class TableHeaderCell : TableCell<Label>
    {
    }
}