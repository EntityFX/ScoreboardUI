﻿namespace EntityFX.ScoreboardUI.Elements.Controls.Table
{
    public class TableCellBase: TableCell<ControlBase>
    {
         
    }
}