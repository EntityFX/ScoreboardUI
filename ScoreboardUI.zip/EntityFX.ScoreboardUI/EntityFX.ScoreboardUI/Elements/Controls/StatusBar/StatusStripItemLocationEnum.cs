﻿namespace EntityFX.ScoreboardUI.Elements.Controls.StatusBar
{
    public enum StatusStripItemLocationEnum
    {
        Left,
        Right
    }
}