﻿namespace EntityFX.ScoreboardUI.Elements.Controls
{
    public class Checkbox : ToggleButtonBase
    {
    }
}