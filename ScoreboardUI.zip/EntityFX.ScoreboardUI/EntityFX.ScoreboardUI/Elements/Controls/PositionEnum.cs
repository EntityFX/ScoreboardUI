﻿namespace EntityFX.ScoreboardUI.Elements.Controls
{
    public enum PositionEnum
    {
        ABSOLUTE,
        RELATIVE
    }
}