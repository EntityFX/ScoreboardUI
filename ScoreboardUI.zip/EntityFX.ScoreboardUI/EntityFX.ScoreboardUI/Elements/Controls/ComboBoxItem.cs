﻿namespace EntityFX.ScoreboardUI.Elements.Controls
{
    public class ComboBoxItem
    {
        public object Key { get; set; }

        public string Text { get; set; }
    }
}