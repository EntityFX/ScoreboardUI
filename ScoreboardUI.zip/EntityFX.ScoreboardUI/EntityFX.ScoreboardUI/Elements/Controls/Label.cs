﻿namespace EntityFX.ScoreboardUI.Elements.Controls
{
    public class Label : ControlBase
    {

    }
}