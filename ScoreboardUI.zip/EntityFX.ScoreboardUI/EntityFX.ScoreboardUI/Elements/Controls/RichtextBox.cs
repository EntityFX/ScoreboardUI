﻿namespace EntityFX.ScoreboardUI.Elements.Controls
{
    public class RichtextBox : TextBox
    {
        public int Lines { get; set; }
    }
}