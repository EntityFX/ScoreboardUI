﻿namespace EntityFX.ScoreboardUI.Elements
{
    public interface ILinearable
    {
        int Width { get; set; } 
    }
}