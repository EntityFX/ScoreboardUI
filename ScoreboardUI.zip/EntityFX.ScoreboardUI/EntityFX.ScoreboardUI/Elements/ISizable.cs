﻿using EntityFX.ScoreboardUI.Drawing;

namespace EntityFX.ScoreboardUI.Elements
{
    public interface ISizable
    {
        Size Size { get; set; }
    }
}