﻿namespace EntityFX.ScoreboardUI
{
    public delegate void FocusChangeEventHandler(
        UiElement sender
        );
}