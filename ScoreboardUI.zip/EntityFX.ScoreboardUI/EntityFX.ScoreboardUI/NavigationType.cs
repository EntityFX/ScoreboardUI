﻿namespace EntityFX.ScoreboardUI
{
    public enum NavigationType
    {
        Navigate,
        GoBack
    }

}
